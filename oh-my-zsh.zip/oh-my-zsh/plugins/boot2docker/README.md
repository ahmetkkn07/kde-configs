## Boot2docker autocomplete plugin

- Adds autocomplete options for all boot2docker commands.


Maintainer : Manfred Touron ([@moul](https://github.com/moul))
